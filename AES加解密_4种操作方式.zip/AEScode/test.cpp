#include <stdio.h>
#include <stdint.h>
int main()
{
	printf("%d",sizeof(uint8_t));
	return 0;
 } 
