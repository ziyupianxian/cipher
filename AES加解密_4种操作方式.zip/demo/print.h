#include<stdio.h>
void printInLine(int data[4][4])
{
	for(int k=0;k<4;k++)
	{
		for(int i=0;i<4;i++)
		{
			printf("%02x",data[i][k]);
		}
	}
	printf("\n");
}
void printMatrix(int data[4][4])
{
	for(int i=0;i<4;i++)
	{
		for(int k=0;k<4;k++)
		{
			printf("%02x\t",data[i][k]);
		}
		printf("\n");
	}printf("\n");
}

