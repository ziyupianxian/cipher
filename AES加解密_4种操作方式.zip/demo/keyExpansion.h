#include <stdio.h>
#include <stdlib.h>
#include"SubBytes.h"
int Nk=4;
int Nr=10;
int data1[4][4]; 
int RC[12]={0,0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1b,0x36,0x6c};
typedef struct word
{
  int a;
  int b;
  int c;
  int d;
};//ÿһ����������4���ֽ�,hex��ʾ��4*2����ĸ 
word exclor(word x,word y)
{
	x.a=x.a^y.a;
		x.b=x.b^y.b;
			x.c=x.c^y.c;
				x.d=x.d^y.d;
	return x;
}
word RotWord(word w)
{
	int t=w.a;
	w.a=w.b;
	w.b=w.c;
	w.c=w.d;
	w.d=t;
	return w;
}

word SubWord(word w)
{
	int i,k,t;
	for( i=0;i<4;i++)
	{
	for( k=0;k<4;k++)
	{
		data1[i][k]=0;
	}
	}	//printData(data);
	data1[0][0]=w.a;
	data1[1][0]=w.b;
	data1[2][0]=w.c;
	data1[3][0]=w.d;
	//printData(data);
	subBytes(data1); 
	w.a=data1[0][0];
		w.b=data1[1][0];
		w.c=data1[2][0];
				w.d=data1[3][0];
			//	printf("%x%x%x%x",w.a,w.b,w.c,w.d);
				return w;
}
void  keyExpansion(struct word w[44],int key[16])
{

	struct word temp;
		struct word Rcon[12];
	int i;
	for(i=0;i<12;i++)
	{
		Rcon[i]={RC[i],0,0,0};
	}
	for( i=0;i<Nk;i++)
	{w[i]={key[4*i],key[4*i+1],key[4*i+2],key[4*i+3]};
//	printf("w[%d]:%x%x%x%x\t",i,key[4*i],key[4*i+1],key[4*i+2],key[4*i+3]);
	 } 
	for(i=Nk;i<4*(Nr+1);i++)
	{
		temp=w[i-1];
		if(i%Nk==0)
		{
	
		temp=RotWord(temp);
		temp=SubWord(temp);	
		temp=exclor(temp,Rcon[i/Nk]);	
		}
		else if(Nk==8 && (i%Nk==4)) 
		{temp=SubWord(temp);
		}
		w[i]=exclor(temp,w[i-Nk]);
		//	if(i==4)printf("4%x%x%x%x\n",w[i].a,w[i].b,w[i].c,w[i].d) ;
	//	printf("%x%x%x%x",w[i].a,w[i].b,w[i].c,w[i].d);
	}
}
