#include<stdio.h>
#include <string.h> 
#include <stdlib.h>
int toHex(int  x)
{
	int hex[6]={0xa,0xb,0xc,0xd,0xe,0xf};
	if(x>9)x=hex[x-10];
	return  x;
}

int main()
{
printf("%x",0x6f/16);
printf("%x",0x6f%16);
	
	getchar();
	return 0;
}



