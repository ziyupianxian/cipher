#include<stdio.h>
 void shiftRows(int data[4][4])
 {
 	int m,n,i;
 	m=data[1][0];
 	for(i=0;i<3;i++)
 	{
 		data[1][i]=data[1][i+1];
	 }
	 data[1][3]=m;
	m= data[2][0];
	n= data[2][1];
for(i=0;i<2;i++)
 	{
 		data[2][i]=data[2][i+2];
	 }
	 data[2][2]=m;
	 data[2][3]=n;
	 m=data[3][3];
	 for(i=3;i>0;i--)
	 {
	 	data[3][i]=data[3][i-1];//ע�ⷽ�򣬲�Ҫ�Ѵ���Ҫ�õ����ݸ�Ĩ���� 
	 }
	 data[3][0]=m;
 }
