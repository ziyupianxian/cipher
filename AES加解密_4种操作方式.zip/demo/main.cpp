#include<stdio.h>
#include "ShiftRows.h" 
#include "keyExpansion.h"
#include "MixColumns.h"
#include <string.h>
#include <time.h>
#include "process.h"
char line[32];
int val[32];
int data[16];
int temp[4][4];
int result[4][4];
struct word w[44];
int key[16];
typedef struct
{
    char* message;
    char* key;
	char* inivector;
	char* mode;
	char* cipher;
}s_param;//�����в���
void equal(int a[4][4],int b[4][4])
{
	for(int i=0;i<4;i++)
	{
		for(int k=0;k<4;k++)
		{
			a[i][k]=b[i][k];
		}
	}
}
void addRoundKey(int a[4][4],int r)
{
	int k;
	for( k=0;k<4;k++)
	{
		a[0][k]=a[0][k]^w[4*r+k].a;
		a[1][k]=a[1][k]^w[4*r+k].b;
		a[2][k]=a[2][k]^w[4*r+k].c;
		a[3][k]=a[3][k]^w[4*r+k].d;
	}
}


void aes(char*message,char*key,char*cipher){
	
 FILE* fp1=fopen(message,"r");
	fread(line,sizeof(char),32,fp1); 
	fclose(fp1);
	chType(line,val);compress(val,data);changeDem(data,temp);
	int i=0;
 FILE* fp2=fopen(key,"r");
	fread(line,sizeof(char),32,fp2); 
	fclose(fp2);
	chType(line,val);compress(val,data);changeDem(data,result);
	keyExpansion(w,data);
	addRoundKey(temp,0);
	
	for(i=1;i<10;i++ )
	{
		if(i==1){
			printf("ѧ�ţ�2020141530051����һ�ֽ����\n");
			printMatrix(temp);
		}
		subBytes(temp);
		shiftRows(temp);
		mixColumns(temp,result);equal(temp,result);	
		addRoundKey(temp,i);
		
	}
	subBytes(temp);
		shiftRows(temp);
		addRoundKey(temp,10);
changeDem(temp,data);
expand(data,val);
chType(val,line);
 FILE* fp3=fopen(cipher,"a");
	fwrite(line,sizeof(char),32,fp3); 
	fclose(fp3);
}
int main(int argc,char *argv[])
{
	s_param param;
	int i=1;
	param.message="message.txt";
	param.cipher="cipher.txt";
	param.key="key.txt";
	param.inivector="inivector.txt";
	param.mode="ECB";//���û���������Ĭ��ΪECB
	while(i<argc)
		{
			if(!strcmp(argv[i],"-p"))
				param.message=argv[i+1];
			else if(!strcmp(argv[i],"-k"))
				param.key=argv[i+1];
			else if(!strcmp(argv[i],"-m"))
				param.mode=argv[i+1];
			else if(!strcmp(argv[i],"-c"))
				param.cipher=argv[i+1];
			else if(!strcmp(argv[i],"-v"))
				param.inivector=argv[i+1];
			i+=2;
		}
		if(!strcmp(param.mode,"ECB"))aes(param.message,param.key,param.cipher);
//	if(!strcmp(param.mode,"ECB"))
//		ECB(param.plainfile,param.keyfile,param.cipherfile);
//	else if(!strcmp(param.mode,"CBC"))
//		CBC(param.plainfile,param.keyfile,param.cipherfile,param.vifile);
//	else if(!strcmp(param.mode,"CFB"))
//		CFB(param.plainfile,param.keyfile,param.cipherfile,param.vifile);
//	else if(!strcmp(param.mode,"OFB"))
//		OFB(param.plainfile,param.keyfile,param.cipherfile,param.vifile);
	else
		printf("����������������:\n");
	printf("ȥ�ļ��￴����");

getchar();
        return 0;
}
