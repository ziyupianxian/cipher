#include <stdio.h>
#include <stdint.h> 
#include <stdlib.h>
#include <time.h>
void print_hex(char *d, int n)
{
    const char hextable[]="0123456789ABCDEF";
    while(n--) putchar(hextable[*d++&15]);
}

void rand32h(char d[32])
{
    int result;
    unsigned char i,n3;
    srand( (unsigned)time( NULL ) ); 
    for (n3=i=0;i<32;)
    {
        if (n3==0) {result = rand(); n3=3;}
        d[i++]=result&15;  
        result>>=4; --n3;
    }
}
 
int  main()
{
    char d[32];  
    rand32h(d);       //���������//
    print_hex(d,32);  
	char s[32];
FILE* fp = fopen("random.txt", "a");//���±������ȱ���Ϊutf8��ʽ,��������utf8��ʽ,�������� 
 for(int t=0;t<40960;t++){
    	for(int i=0;i<32;i++)
    		{
			switch(d[i])
			{
				case 0x0:s[i]='0';break;
				case 0x01:s[i]='1';break;
				case 0x02:s[i]='2';break;
				case 0x03:s[i]='3';break;
				case 0x04:s[i]='4';break;
				case 0x05:s[i]='5';break;
				case 0x06:s[i]='6';break;
				case 0x07:s[i]='7';break;
				case 0x08:s[i]='8';break;
				case 0x09:s[i]='9';break;
				case 0x0a:s[i]='a';break;
				case 0x0b:s[i]='b';break;
				case 0x0c:s[i]='c';break;
				case 0x0d:s[i]='d';break;
				case 0x0e:s[i]='e';break;
				case 0x0f:s[i]='f';break;
				
			}
			}
			for(int i=0;i<32;i++)
			{
				printf("%c",s[i]);
			}
			
    fwrite(s, sizeof(char),32, fp);
}
     fclose(fp);
    putchar('\n');
    getchar();
    return 0;
}
