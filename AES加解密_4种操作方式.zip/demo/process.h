#include <stdio.h>
#include <math.h>
int toHex(char a)
{
	int x;
	if(a=='A')x=0xA;
	else if(a=='B')x=0xB;
		else if(a=='C')x=0xC;
			else if(a=='D')x=0xD;
				else if(a=='E')x=0xE;
					else if(a=='F')x=0xF;
					else x=a-'0';
					return x;
}
void compress(int a[32],int b[16])
{	

	for(int i=0;i<16;i++)
	{
		b[i]=a[2*i]*16+a[2*i+1];
//		printf("%x=%x*16+%x\n",b[i],a[i],a[i+1]);
	}
}
void chType(char a[32],int b[32])
{
		for(int i=0;i<32;i++)
	{
b[i]=toHex(a[i]);
	}
}
void changeDem(int data[16],int newD[4][4])
{
		for(int k=0;k<4;k++)
	{
		for(int i=0;i<4;i++)
		{
			newD[k][i]=data[i*4+k];
//			printf("data[%d][%d]=%x\n",k,i,newD[k][i]);
		}
}
 } 
void changeDem(int data[4][4],int newD[16]){
//{printf("��ά\n");
		for(int k=0;k<4;k++)
	{
		for(int i=0;i<4;i++)
		{
		newD[i*4+k]=data[k][i];
//		printf("%02x",data[k][i]);
		}
}}

void expand(int a[16],int b[32])
{	

//	for(int i=0;i<16;i++)
//	{
//		b[i]=a[2*i]*16+a[2*i+1];
////		printf("%x=%x*16+%x\n",b[i],a[i],a[i+1]);
//	}
for(int i=0;i<32;i+=2)
{
	b[i]=a[i/2]/16;
	b[i+1]=a[i/2]%16;
}
}
char toChar(int x)
{
	char a[16]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
	return a[x];
}
void chType(int a[32],char b[32])
{
		for(int i=0;i<32;i++)
	{
		b[i]=toChar(a[i]);
//		printf("%c",b[i]);
	}
}

